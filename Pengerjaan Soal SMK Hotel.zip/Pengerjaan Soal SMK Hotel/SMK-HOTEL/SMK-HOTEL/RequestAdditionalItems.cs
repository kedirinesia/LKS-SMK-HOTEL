﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace SMK_HOTEL
{
    public partial class RequestAdditionalItems : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private SqlDataReader rd;
        private SqlDataAdapter da;
        private DataSet ds;




        public RequestAdditionalItems()
        {
            InitializeComponent();
        }

        public void MunculData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Item", typeof(string));
            dt.Columns.Add("Quantity", typeof(string));
            dt.Columns.Add("Price", typeof(string));
            dt.Columns.Add("Sub Total", typeof(string));
            dataGridView1.DataSource = dt;
        
        }

        public void isiRoomNumber()
        {
            comboBox1.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT RoomNumber FROM Room ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader["RoomNumber"].ToString());
                    }

                    reader.Close();
                }
            }
        }

        public void IsiItem()
        {
            comboBox2.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT Name FROM Item ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader["Name"].ToString());
                    }

                    reader.Close();
                }
            }
        }



        public void awal()
        {
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            MunculData();
            isiRoomNumber();
            IsiItem();




        }






        private void RequestAdditionalItems_Load(object sender, EventArgs e)
        {
            awal();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedName = comboBox2.SelectedItem?.ToString();
            if (selectedName != null)
            {
                using (SqlConnection conn = Konn.GetConn())
                {
                    conn.Open();
                    string query = "SELECT RequestPrice FROM Item WHERE Name = @Name";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", selectedName);

                        object result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            if (decimal.TryParse(result.ToString(), out decimal requestPrice))
                            {
                                textBox1.Text = requestPrice.ToString(); // Menampilkan harga satuan di textBox3

                                decimal multiplier = numericUpDown1.Value;
                                decimal total = requestPrice * multiplier;
                                textBox2.Text = total.ToString();
                            }
                            else
                            {
                                textBox1.Text = "Invalid Price";
                                textBox2.Text = "";
                            }
                        }
                        else
                        {
                            textBox1.Text = "Price not found";
                            textBox2.Text = "";
                        }
                    }
                }
            }
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            string selectedName = comboBox2.SelectedItem?.ToString();
            if (selectedName != null)
            {
                using (SqlConnection conn = Konn.GetConn())
                {
                    conn.Open();
                    string query = "SELECT RequestPrice FROM Item WHERE Name = @Name";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", selectedName);

                        object result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            if (decimal.TryParse(result.ToString(), out decimal requestPrice))
                            {
                                textBox1.Text = requestPrice.ToString(); // Menampilkan harga satuan di textBox3

                                decimal multiplier = numericUpDown1.Value;
                                decimal total = requestPrice * multiplier;
                                textBox2.Text = total.ToString();
                            }
                            else
                            {
                                textBox1.Text = "Invalid Price";
                                textBox2.Text = "";
                            }
                        }
                        else
                        {
                            textBox1.Text = "Price not found";
                            textBox2.Text = "";
                        }
                    }
                }
            }
        }
    }
    }
