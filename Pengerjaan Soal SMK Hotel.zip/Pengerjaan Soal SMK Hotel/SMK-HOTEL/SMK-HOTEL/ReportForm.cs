﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SMK_HOTEL
{
    public partial class ReportForm : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;


        public ReportForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime tanngalawal, tanggalakhir;
          

            if (radioButton1.Checked)
            {

                tanngalawal = DateTime.Now.Date;
                tanggalakhir = DateTime.Now.Date;
                //MessageBox.Show(DateTime.Now.Date.ToString());

            }
            else
            {
                tanngalawal = dateTimePicker1.Value;
                tanggalakhir = dateTimePicker2.Value;
            }
           
            
              using (SqlConnection conn = Konn.GetConn())
            { 

                   conn.Open();
                    {
                        string query = "select * from ReservationRoom where CheckInDateTime >= @TglAwal AND CheckInDateTime <= @TglAkhir  ";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@TglAwal", tanngalawal);
                            cmd.Parameters.AddWithValue("@TglAkhir", tanggalakhir);
                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable tgl = new DataTable();
                            adapter.Fill(tgl);
                            dataGridView1.DataSource = tgl;
                        }





                        //ReportInChartForm reportInChartForm = new ReportInChartForm();
                        //reportInChartForm.Show();
                        //this.Close();
                   
                }
            }
        }


        public void hitunghari()
        {
            DateTime checkInDate = dateTimePicker1.Value;
            DateTime checkOutDate = dateTimePicker2.Value;

            TimeSpan selisih = checkOutDate.Subtract(checkInDate);

            int selisihHari = (int)Math.Ceiling(selisih.TotalDays);

            textBox1.Text = selisihHari.ToString();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            dateTimePicker1.Value = DateTime.Now;
            dateTimePicker2.Value = DateTime.Now;
            radioButton2.Focus();
            //label1.Visible = false;
            //dateTimePicker1.Visible = false;
            //dateTimePicker2.Visible = false;
            //textBox1.ReadOnly = true;

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //hitunghari();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            //hitunghari();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //label1.Visible = true;
            //dateTimePicker1.Visible = true;
            //dateTimePicker2.Visible = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = DateTime.Now.ToString();

           
        }
    }
}
