﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SMK_HOTEL
{
    public partial class MasterItem : Form
    {
        private Connection Konn = new Connection();
        private SqlDataAdapter da;
        private DataSet ds;
        private SqlDataReader rd;
        public MasterItem()
        {
            InitializeComponent();
        }
        void awal()
        {
            munculdata();
        }

        void munculdata()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select * from item", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
        }

        private void MasterItem_Load(object sender, EventArgs e)
        {
            awal();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox9.Text) || string.IsNullOrEmpty(textBox8.Text) || string.IsNullOrEmpty(textBox7.Text))
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();


                        string query = "INSERT INTO Item (Name, RequestPrice, CompesationFee) " +
                            "VALUES (@Name, @RequestPrice, @CompesationFee)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox9.Text);
                            cmd.Parameters.AddWithValue("@RequestPrice", textBox8.Text);
                            cmd.Parameters.AddWithValue("@CompesationFee", textBox7.Text);


                            cmd.ExecuteNonQuery();
                            Refresh();
                        }



                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox9.Text) || string.IsNullOrWhiteSpace(textBox8.Text) || string.IsNullOrWhiteSpace(textBox7.Text))
            {
                MessageBox.Show("Harap isi semua formulir");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                        string query = "UPDATE ITEM SET Name = @Name, RequestPrice = @RequestPrice, CompesationFee = @CompesationFee WHERE Name = @Name";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                           
                            cmd.Parameters.AddWithValue("@Name", textBox9.Text);
                            cmd.Parameters.AddWithValue("@RequestPrice", Convert.ToDecimal(textBox8.Text));  
                            cmd.Parameters.AddWithValue("@CompesationFee", Convert.ToDecimal(textBox7.Text)); 

                            cmd.ExecuteNonQuery();
                            Refresh();
                        }

                        MessageBox.Show("DATA BERHASIL DIUPDATE");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (FormatException ex)
                {
                    MessageBox.Show("Harap masukkan angka untuk Request Price dan Compesation Fee");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }

        } 

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string nilai = row.Cells[1].Value.ToString();
                string nilai1 = row.Cells[0].Value.ToString();
                string nilai2 = row.Cells[2].Value.ToString();
                string nilai3 = row.Cells[3].Value.ToString();


                textBox9.Text = nilai;
                textBox8.Text = nilai2;

                textBox7.Text = nilai3;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox9.Text) || string.IsNullOrWhiteSpace(textBox8.Text) || string.IsNullOrWhiteSpace(textBox7.Text))
            {
                MessageBox.Show("Harap isi semua formulir");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        {
                            conn.Open();




                            string query = "DELETE FROM ITEM WHERE Name = @Name ";
                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@Name", textBox9.Text);

                                int rowsAffected = cmd.ExecuteNonQuery();

                                cmd.ExecuteNonQuery();
                                Refresh();
                            }




                            MessageBox.Show("DATA BERHASIL DIHAPUS");
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Berhasil Menyimpan");
        }
    }
}

