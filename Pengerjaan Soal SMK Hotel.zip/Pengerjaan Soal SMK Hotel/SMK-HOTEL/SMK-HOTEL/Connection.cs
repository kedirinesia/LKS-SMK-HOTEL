﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace SMK_HOTEL
{
    internal class Connection
    {
        public SqlConnection GetConn()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=PULUNG\\SQLEXPRESS;Initial Catalog=SMKHOTEL;Integrated Security=True";
            return conn;

        }
    }
}
