﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Globalization;

namespace SMK_HOTEL
{
    public partial class CheckOut : Form
    {
        Connection Konn = new Connection();
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;
        private SqlCommand cmd;
        public int totalharga;
        public CheckOut()
        {
            InitializeComponent();
            comboBox1.DataSource = null;
            isiRoomNumber();
        }


        private void UpdateBiaya()
        {
            //int harga = 0;

            //int sumharga = 0;
            //for (int i = 0; i < dataGridView4.Rows.Count; i++)
            //{
            //    //int valueFromCell;
            //    //int.TryParse(dataGridView4.Rows[i].Cells[3].Value.ToString(), out valueFromCell);

            //    sumharga += int.Parse(dataGridView4.Rows[i].Cells[3].Value.ToString());







            //}


            //label3.Text = "Total Price: " + sumharga.ToString();

            int harga = 0;
            int sumharga = 0;

            for (int i = 0; i < dataGridView4.Rows.Count; i++)
            {
                int valueFromCell;
                if (int.TryParse(dataGridView4.Rows[i].Cells[3].Value?.ToString(), out valueFromCell))
                {
                    sumharga += valueFromCell;
                }
                else
                {

                }
            }
            int food = 0;
            int hargafood = 0;

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                int valueFromCell;
                if (int.TryParse(dataGridView1.Rows[i].Cells[2].Value?.ToString(), out valueFromCell))
                {
                    hargafood += valueFromCell;
                }
                else
                {

                }
            }
            int totalharga = hargafood + sumharga;


            //int biayaItem = 0;

            //if (dataGridView4.RowCount != 0)
            //{
            //    int sumItem = 0;
            //    for (int i = 0; i < dataGridView4.Rows.Count; i++)
            //    {
            //        int valueFromCell;
            //        if (int.TryParse(dataGridView4.Rows[i].Cells[3].Value?.ToString(), out valueFromCell))
            //        {
            //            sumItem += valueFromCell;
            //        }

            //    }
            //    biayaItem = sumItem;
            //}



            label3.Text = "Total Price: " + sumharga.ToString();
            label4.Text = "Total Price: " + hargafood.ToString();
            textBox4.Text = totalharga.ToString();
            label9.Text = "Total Charge:" + totalharga.ToString();
            
        }

        void awal()
        {
            MunculData();
            MunculData2();
        }

        void MunculData2()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Quantity", typeof(int));
            dt.Columns.Add("Compensation Fee", typeof(int));
            dt.Columns.Add("Sub Total", typeof(int));
            dataGridView4.DataSource = dt;
        }

        void MunculData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Item", typeof(string));
            dt.Columns.Add("Quantity", typeof(int));
            dt.Columns.Add("Compensation Fee", typeof(int));
            dt.Columns.Add("Sub Total", typeof(int));
            dataGridView1.DataSource = dt;

        }

        private void CheckOut_Load(object sender, EventArgs e)
        {

        }

        public void isiItem()
        {
            comboBox2.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT Name FROM Item ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader["Name"].ToString());
                    }

                    reader.Close();
                }
            }
        }

        public void isiRoomNumber()
        {
            comboBox1.DataSource = null;
            comboBox1.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT ID, RoomNumber FROM Room WHERE ID IN (SELECT RoomID FROM ReservationRoom)", conn);

                    SqlDataReader reader = command.ExecuteReader();

                    DataTable dt = new DataTable();
                    dt.Load(reader);

                    comboBox1.DisplayMember = "RoomNumber";
                    comboBox1.ValueMember = "ID";
                    comboBox1.DataSource = dt;

                    reader.Close();
                }
            }
        }


        public void isicombobox3()
        {
            comboBox3.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT Name FROM ItemStatus ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox3.Items.Add(reader["Name"].ToString());

                    }

                    reader.Close();
                }
            }
        }

        private void CheckOut_Load_1(object sender, EventArgs e)
        {
            textBox4.Visible = false;
            label9.Visible = false;
            textBox1.ReadOnly = true;
            textBox2.Visible = false;
            textBox3.ReadOnly = true;
            awal();
            isiRoomNumber();
            isiItem();
            isicombobox3();

        }
        public void isicombobox()
        {
            string selectedName = comboBox2.SelectedItem?.ToString();
            if (selectedName != null)
            {
                using (SqlConnection conn = Konn.GetConn())
                {
                    conn.Open();
                    string query = "SELECT RequestPrice FROM Item WHERE Name = @Name";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", selectedName);

                        object result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            if (decimal.TryParse(result.ToString(), out decimal requestPrice))
                            {
                                textBox2.Text = requestPrice.ToString(); // Menampilkan harga satuan di textBox3

                                decimal multiplier = numericUpDown1.Value;
                                decimal total = requestPrice * multiplier;
                                decimal compe = total * 2;
                                textBox3.Text = total.ToString();
                                textBox1.Text = compe.ToString();
                            }
                            else
                            {
                                textBox2.Text = "Invalid Price";
                                textBox3.Text = "";
                            }
                        }
                        else
                        {
                            textBox2.Text = "Price not found";
                            textBox3.Text = "";
                        }
                    }
                }
            }
        }


        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            isicombobox();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            isicombobox();
        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {


            string ItemStatus = comboBox3.Text;
            string Item = comboBox2.Text;
            int compensationFee = Convert.ToInt32(textBox1.Text);
            int Quantity = Convert.ToInt32(numericUpDown1.Value);
            int Subtotal = int.Parse(textBox3.Text);

            DataTable dt = dataGridView4.DataSource as DataTable;
            dt.Rows.Add(Item, Quantity, compensationFee, Subtotal);

            dataGridView4.DataSource = dt;

            UpdateBiaya();

            label9.Visible = true;



        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                int selectedReservationRoomID = 0;


                if (comboBox1.SelectedValue != null && int.TryParse(comboBox1.SelectedValue.ToString(), out selectedReservationRoomID))
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        try
                        {
                            conn.Open();

                            string query = "SELECT Name, Type, Price FROM FoodsAndDrinks FD " +
                                           "JOIN ReservationRoom RR ON FD.ID = RR.ID " +
                                           "WHERE RR.ID = @SelectedReservationRoomID";

                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@SelectedReservationRoomID", selectedReservationRoomID);
                                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                                DataTable roomData = new DataTable();
                                adapter.Fill(roomData);


                                dataGridView1.DataSource = null;
                                dataGridView1.Columns.Clear();
                                dataGridView1.Rows.Clear();

                                dataGridView1.DataSource = roomData;

                                UpdateBiaya();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Tidak ada item yang dipilih atau ID tidak valid.");
                }
            }
        }



        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                string query = "INSERT INTO FDCheckOut (TotalPrice, Qty) " +
                          "VALUES (@TotalPrice, @Qty )";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@TotalPrice", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Qty", numericUpDown1.Value);


                    cmd.ExecuteNonQuery();
                    Refresh();

                    MessageBox.Show("Berhasil Melakukan checkout");
                }
            }
        }
    }
}
