﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace SMK_HOTEL
{
    public partial class MasterEmployee : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;
        public MasterEmployee()
        {
            InitializeComponent();
        }

        void awal()
        {
            this.Controls.Add(txt2);
            this.Controls.Add(txt3);
            munculdata();
        }

        void munculdata()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select * from Employee", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }

                }
            }
        }
        private void MasterEmployee_Load(object sender, EventArgs e)
        {
            txt2.PasswordChar = '*';
            txt3.PasswordChar = '*';
            awal();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string password = txt2.Text;
           
            string confirm = txt3.Text;
            if (password != confirm)
            {
                MessageBox.Show("Password Tidak Cocok");
                return;
            }

            if (string.IsNullOrEmpty(txt1.Text) || string.IsNullOrEmpty(txt2.Text) ||
                string.IsNullOrEmpty(txt4.Text) || string.IsNullOrEmpty(txt5.Text) ||
                string.IsNullOrEmpty(txt6.Text) || string.IsNullOrEmpty(txt7.Text) ||
                dateTimePicker1.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();
                        string query = "INSERT INTO Employee (Username, Password, Name, Email, DateOfBirth, Job, Address, Photo) " +
                                        "VALUES (@Username, @Password, @Name, @Email, @DateOfBirth, @Job, @Address, @Photo)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Username", txt1.Text);
                            cmd.Parameters.AddWithValue("@Password", txt2.Text);
                            cmd.Parameters.AddWithValue("@Name", txt4.Text);
                            cmd.Parameters.AddWithValue("@Email", txt5.Text);
                            cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value);
                            cmd.Parameters.AddWithValue("@Job", txt6.Text);
                            cmd.Parameters.AddWithValue("@Address", txt7.Text);

                           
                            byte[] dataGambar;
                            if (pictureBox1.Image != null)
                            {
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
                                    dataGambar = ms.ToArray();
                                }
                            }
                            else
                            {
                           
                                dataGambar = null; 
                            }

                            cmd.Parameters.AddWithValue("@Photo", dataGambar);
                            cmd.ExecuteNonQuery();
                            Refresh();
                        }
                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {

            string password = txt2.Text;
            string confirm = txt3.Text;
            if (password != confirm)
            {
                MessageBox.Show("Password Tidak Cocok");
                return;
            }
            if (string.IsNullOrEmpty(txt1.Text) || string.IsNullOrEmpty(txt2.Text) || /*string.IsNullOrEmpty(txt3.Text) ||*/
             string.IsNullOrEmpty(txt4.Text) || string.IsNullOrEmpty(txt5.Text) || string.IsNullOrEmpty(txt6.Text) ||
             string.IsNullOrEmpty(txt7.Text) ||
             dateTimePicker1.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();
                        string query = "UPDATE Employee SET Username = @Username, Password = @Password, Name = @Name, Email = @Email, DateOfBirth = @DateOfBirth , Job = @Job WHERE Username = @Username";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {

                            cmd.Parameters.AddWithValue("@Username", txt1.Text);
                            cmd.Parameters.AddWithValue("@Password", txt2.Text);
                            cmd.Parameters.AddWithValue("@Name", txt4.Text);
                            cmd.Parameters.AddWithValue("@Email", txt5.Text);
                            cmd.Parameters.AddWithValue("@DateOfBirth", dateTimePicker1.Value);
                            cmd.Parameters.AddWithValue("@Job", txt6.Text);
                            cmd.Parameters.AddWithValue("@Address", txt7.Text);
                            cmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("DATA BERHASIL DIUPDATE");
                    }
                }
                catch (SqlException ex)
                {

                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {

                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt1.Text) || string.IsNullOrEmpty(txt2.Text) || /*string.IsNullOrEmpty(txt3.Text) ||*/
               string.IsNullOrEmpty(txt4.Text) || string.IsNullOrEmpty(txt5.Text) || string.IsNullOrEmpty(txt6.Text) ||
               string.IsNullOrEmpty(txt7.Text) ||
               dateTimePicker1.Value == DateTimePicker.MinimumDateTime)
            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                        string query = "DELETE FROM Employee WHERE Username = @Username";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Username", txt1.Text);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("DATA BERHASIL DIHAPUS");
                                awal();
                            }
                            else
                            {
                                MessageBox.Show("Tidak ada data yang dihapus.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)

        {
            string password = txt2.Text;
            string confirm = txt3.Text;
            if (password != confirm)
            {
                MessageBox.Show("Password Tidak Cocok");
            }
            this.Close();
            MessageBox.Show("berhasil menyimpan");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            txt1.Text = string.Empty;
            txt2.Text = string.Empty;
            txt3.Text = string.Empty;   
            txt4.Text = string.Empty;
            txt5.Text = string.Empty;
            txt6.Text = string.Empty;
            txt7.Text = string.Empty;

            MessageBox.Show("Berhasil Melakukan Cancel");
        }

        private void txt3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog filefoto = new OpenFileDialog();
            filefoto.Filter = "Gambar (*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp";
            filefoto.Title = "Pilih Gmabar";
            if (filefoto.ShowDialog() == DialogResult.OK)
            {
                string path = filefoto.FileName;
                pictureBox1.Image = Image.FromFile(path);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }
    }
}
