﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SMK_HOTEL
{
    public partial class ReportInChartForm : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;


        public ReportInChartForm()
        {
            InitializeComponent();



        }

        private void ReportInChartForm_Load(object sender, EventArgs e)
        {

            messi();
            FillChartSeries();
        }

        string NamaBulan(int Value)
        {
            switch (Value)
            {
                case 1:
                    return "Januari";
                case 2:
                    return "Februari";
                case 3:
                    return "Maret";
                case 4:
                    return "April";
                case 5:
                    return "Mei";
                case 6:
                    return "Juni";
                case 7:
                    return "Juli";
                case 8:
                    return "Agustus";
                case 9:
                    return "September";
                case 10:
                    return "Oktober";
                case 11:
                    return "November";
                case 12:
                    return "Desember";
                default:
                    return "Bulan tidak valid";
            }
           
        }

        void messi()
        {

            Series Messi = new Series("Messi");
            Messi.ChartType = SeriesChartType.Line;

            Messi.Points.AddXY(1, 2000);
            Messi.Points.AddXY(2, 2000);
            Messi.Points.AddXY(3, 5000);
            Messi.Points.AddXY(4, 1000000);


            chart1.Series.Add(Messi);
        }

        private void FillChartSeries()
        {

            Series mySeries = new Series("Alok");
            mySeries.ChartType = SeriesChartType.Line;

            mySeries.Points.AddXY(1, 2023);
            mySeries.Points.AddXY(2, 2023);
            mySeries.Points.AddXY(3, 2023);
            mySeries.Points.AddXY(4, 2023);


            chart1.Series.Add(mySeries);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("halo");


            //chart1.Series["Messi"].Points.AddY(100);
            //chart1.Series["Messi"].Points.AddY(10);
            //chart1.Series["Messi"].Points.AddY(11);
            //chart1.Series["Alok"].Points.AddXY(1, 20);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedFilter = comboBox1.SelectedItem.ToString();


            if (selectedFilter == "Pilihan 1")
            {

                chart1.Series["Messi"].Points.Clear();
                chart1.Series["Messi"].Points.AddXY(1, 2000);
                chart1.Series["Messi"].Points.AddXY(2, 2000);
                chart1.Series["Messi"].Points.AddXY(3, 5000);
                chart1.Series["Messi"].Points.AddXY(4, 1000000);


            }
            else if (selectedFilter == "Pilihan 2")
            {



                chart1.Series["Alok"].Points.Clear();
                chart1.Series["Alok"].Points.AddXY(1, 2023);
                chart1.Series["Alok"].Points.AddXY(2, 2023);
                chart1.Series["Alok"].Points.AddXY(3, 2023);
                chart1.Series["Alok"].Points.AddXY(4, 2023);
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void ReportInChartForm_Load_1(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            comboBox1.Items.Clear();
            int awal = 1900;
            int akhir = 2023;
            for (int i = akhir; i >= awal; i--)
            {
                comboBox1.Items.Add(i.ToString());
            }
            comboBox1.Text = DateTime.Now.Year.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {


            using (SqlConnection conn = Konn.GetConn())
            {

                conn.Open();
                {
                    string query = "select count(ReservationID) as Jumlah, month(CheckInDateTime) as bulan from ReservationRoom where year(CheckInDateTime) = @Tahun group by month(CheckInDateTime);  ";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Tahun",comboBox1.Text);
                       
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable tgl = new DataTable();
                        adapter.Fill(tgl);
                        dataGridView1.DataSource = tgl;

                        string tamu = " The Chart Of Number Guests In " + comboBox1.Text;

                        this.chart1.Series.Clear();
                        this.chart1.Titles.Clear();
                        this.chart1.Titles.Add(tamu);

                        Series series = this.chart1.Series.Add("Tamu");
                        
                        series.ChartType = SeriesChartType.Column;
                       

                        foreach (DataRow row in tgl.Rows)
                        {

                            
                            series.Points.AddXY(NamaBulan(int.Parse(row["Bulan"].ToString())), row["Jumlah"].ToString());

                        }
                       
                        //SqlDataAdapter adapter2 = new SqlDataAdapter(query2, conn);
                        //DataTable tgl2 = new DataTable();
                        //adapter2.Fill(tgl2);

                     
                        //Series series2 = this.chart1.Series.Add("Tamu Tanpa Check In");
                        //series2.ChartType = SeriesChartType.Column;

                       
                        //foreach (DataRow row in tgl2.Rows)
                        //{
                        //    series2.Points.AddXY(NamaBulan(int.Parse(row["Bulan"].ToString())), row["Jumlah"].ToString());
                        //}

                    }
                }
            }
        }
    }
}
