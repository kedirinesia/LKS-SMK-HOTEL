﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;


namespace SMK_HOTEL
{
    public partial class CustomerCheckin : Form
    {

        Connection Konn = new Connection();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        public CustomerCheckin()
        {
            InitializeComponent();
        }

        void awal()
        {
            MunculData();

        }
        private void button3_Click(object sender, EventArgs e)
        {
            MainFormm mainfrm = new MainFormm();
            this.Close();
        }

        void MunculData()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT RoomNumber, RoomFloor, Name, StartDateTime from Room, RoomType, ReservationRoom", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;

                    }
                }
            }
        }
        private void CustomerCheckin_Load(object sender, EventArgs e)
        {
            awal();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Periksa apakah semua form telah diisi dan jenis kelamin dipilih
            if (string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) ||
                string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(textBox6.Text) ||
                string.IsNullOrEmpty(textBox7.Text) || (!radioButton1.Checked && !radioButton2.Checked))
            {
                MessageBox.Show("Pastikan semua form diisi dan jenis kelamin dipilih.");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();
                        string query = "INSERT INTO Customer (Email, Gender, Name, PhoneNumber, NIK, Age) " +
                                       "VALUES (@Email, @Gender, @Name, @PhoneNumber, @NIK, @Age)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Email", textBox2.Text);
                            cmd.Parameters.AddWithValue("@NIK", textBox3.Text);
                            cmd.Parameters.AddWithValue("@Name", textBox5.Text);
                            cmd.Parameters.AddWithValue("@PhoneNumber", textBox6.Text);
                            cmd.Parameters.AddWithValue("@Age", textBox7.Text);

                            
                            string gender = radioButton1.Checked ? "Male" : "Female";
                            cmd.Parameters.AddWithValue("@Gender", gender);

                            cmd.ExecuteNonQuery();
                        }
                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }
    }
}
