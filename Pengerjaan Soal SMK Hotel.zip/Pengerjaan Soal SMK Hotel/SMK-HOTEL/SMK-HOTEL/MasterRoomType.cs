﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SMK_HOTEL
{
    public partial class MasterRoomType : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private DataSet ds;
        private SqlDataReader rd;


        void awal()
        {
            munculdata();
        }

        void munculdata()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select Name, Capacity, RoomPrice from RoomType", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;

                    }
                }
            }

        }
        public MasterRoomType()
        {
            InitializeComponent();
        }

        private void MasterRoomType_Load(object sender, EventArgs e)
        {
            awal();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = ("Gambar (*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp");
            openFileDialog.Title = "Pilih Gambar";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog.FileName;
                pictureBox1.Image = Image.FromFile(path);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox3.Text) || numericUpDown1.Value == 0)
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();


                        Image image = pictureBox1.Image;
                        image.Save("temp.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                        byte[] blob = System.IO.File.ReadAllBytes("temp.jpg");


                        string query = "INSERT INTO RoomType (Name, Capacity, RoomPrice, photo) " +
                            "VALUES (@Name, @Capacity, @RoomPrice, @photo)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                            cmd.Parameters.AddWithValue("@Capacity", numericUpDown1.Value);
                            cmd.Parameters.AddWithValue("@RoomPrice", textBox3.Text);
                            cmd.Parameters.AddWithValue("@photo", blob);

                            cmd.ExecuteNonQuery();
                            Refresh();
                        }


                        System.IO.File.Delete("temp.jpg");

                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string nilai = row.Cells[1].Value.ToString();
                string nilai1 = row.Cells[0].Value.ToString();
                string nilai2 = row.Cells[2].Value.ToString();
            


                textBox1.Text = nilai1;
                textBox3.Text = nilai2;

                numericUpDown1.Text = nilai;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox3.Clear();
            numericUpDown1.Value = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox3.Text) || numericUpDown1.Value == null)
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                         


                        string query = "DELETE FROM RoomType WHERE Name = @Name "; 
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            cmd.ExecuteNonQuery();
                            Refresh();
                        }


                    

                        MessageBox.Show("DATA BERHASIL DIHAPUS");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            MessageBox.Show("Berhasil Melakukan Save");
        }
    }
}
