﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMK_HOTEL
{
    public partial class MainFormFrontOffice : Form
    {
        public MainFormFrontOffice()
        {
            InitializeComponent(); Timer timer = new Timer();
            timer.Interval = 1000;  
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Mendapatkan waktu  dari sistem
            DateTime currentTime = DateTime.Now;


            LabelWaktu.Text = currentTime.ToLongTimeString(); // Tampilkan waktu
            LabelTanggal.Text = currentTime.ToLongDateString(); // Tampilkan tanggal
        }


        private void foodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterFoodandDrink masterFoodandDrink = new MasterFoodandDrink();
            masterFoodandDrink.Show();
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            this.Hide();
           MainFormm mainfrm = new MainFormm();
            mainfrm.Show();
        }

        private void toolStripLabel5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            MasterEmployee masterEmployee = new MasterEmployee();
            masterEmployee.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterEmployee employee = new MasterEmployee(); 
            employee.Show();
        }

        private void itemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterItem masterItem = new MasterItem();   
            masterItem.Show();
        }

        private void roomTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterRoomType masterRoomType = new MasterRoomType();
            masterRoomType.Show();
        }

        private void roomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterRoom room = new MasterRoom();
            room.Show();
        }

        private void MainFormFrontOffice_Load(object sender, EventArgs e)
        {

        }
    }
}
