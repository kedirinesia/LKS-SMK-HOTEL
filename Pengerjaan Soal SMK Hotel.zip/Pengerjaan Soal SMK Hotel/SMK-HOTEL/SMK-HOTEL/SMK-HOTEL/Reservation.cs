﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SMK_HOTEL
{
    public partial class Reservation : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private DataSet ds;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        public string nilai4, nilai5, nilai6;
        public int RoomPricee;
        public int roomPrice = 0;
        int totalBiayaMethod1 = 0;
        DataTable table = new DataTable();
        string CustomerID;
        int totalBiayaMethod2 = 0;


        //public string 




        public void RoomPrice()
        {

            int roomPrice = 0;


            if (dataGridView2.Rows.Count > 0 && dataGridView2.Columns["RoomPrice"] != null)
            {

                object cellValue = dataGridView2.Rows[0].Cells["RoomPrice"].Value;


                if (cellValue != null && cellValue != DBNull.Value)
                {
                    roomPrice = Convert.ToInt32(cellValue);
                }
            }
        }
        private void filter()
        {
           
            try
            {
                using (SqlConnection conn = Konn.GetConn())
                {
                     
                    string selectedCategory = comboBox1.SelectedItem.ToString();
                    //                    string filterQuery = "SELECT RoomNumber, RoomFloor, RoomPrice, Description from Room, RoomType WHERE Description LIKE  '%" + comboBox1.Text + "%'";
                   

/*                    string getQueryID = "SELECT ID From RoomType where Name =" + comboBox1.Text;
                    SqlDataAdapter adapter = new SqlDataAdapter(getQueryID, conn);
                    DataTable dataTable = new DataTable();
                    
                    adapter.Fill(dataTable);
                    MessageBox.Show(dataTable.Rows.Count.ToString());

                    int RoomTypeID = int.Parse(dataTable.Rows[0][0].ToString());
                    MessageBox.Show(RoomTypeID.ToString() + comboBox1.Text);
*/                    
                    string filterQuery = "SELECT RoomNumber, RoomFloor, (Select RoomPrice from RoomType where RoomType.id=Room.RoomTypeID) as RoomPrice, RoomTypeID from Room WHERE RoomTypeID = " + (comboBox1.SelectedIndex+1).ToString() + "";

                    SqlDataAdapter adapter1 = new SqlDataAdapter(filterQuery, conn);
                    DataTable dataTable1 = new DataTable();
                    adapter1.Fill(dataTable1);
                     
                    dataGridView2.DataSource = dataTable1;
                }
                SqlConnection ckonn = Konn.GetConn();
                ckonn.Close();
            }
            catch
            {

            }
            }



        public void item()
        {
            comboBox2.Items.Clear();
            HashSet<string> itemNames = new HashSet<string>(); // Gunakan HashSet untuk menyimpan nama barang yang unik

            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT Name FROM Item", conn);

                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string itemName = reader["Name"].ToString();
                        if (!itemNames.Contains(itemName))
                        {
                            comboBox2.Items.Add(itemName);
                            itemNames.Add(itemName);
                        }
                    }

                    reader.Close();
                }
            }
        }




        public void LoadDataToComboBox()
        {

            comboBox1.Items.Clear();
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT Description FROM Room ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader["Description"].ToString());
                    }

                    reader.Close();
                }
            }
        }

        void awal()
        {
            tabelbawah();
            LoadData();
            item();
            LoadDataToComboBox();
            //MunculData();
            //MunculData2();
            //MunculData3();
            //MunculData4();
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox2.ReadOnly = true;  
        }

        private void LoadData()
        {
            try
            {

                using (SqlConnection conn = Konn.GetConn())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("select RoomNumber, RoomFloor, RoomPrice, Description from Room, RoomType", conn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            da.Fill(dataTable);
                            dataGridView5.DataSource = dataTable;
                        }
                        dataGridView5.Visible = false;


                        if (dataGridView2.Columns.Count == 0)
                        {
                            foreach (DataGridViewColumn dgvc in dataGridView5.Columns)
                            {
                                dataGridView2.Columns.Add(dgvc.Clone() as DataGridViewColumn);
                            }
                        }


                        foreach (DataGridViewRow dgvRow in dataGridView5.Rows)
                        {
                            DataGridViewRow row = dgvRow.Clone() as DataGridViewRow;
                            for (int i = 0; i < dgvRow.Cells.Count; i++)
                            {
                                row.Cells[i].Value = dgvRow.Cells[i].Value;
                            }
                            dataGridView2.Rows.Add(row);
                        }

                        dataGridView2.AllowUserToAddRows = false;
                        dataGridView2.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("Terjadi kesalahan: " + ex.Message);
            }


        }


        void MunculData()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select Name, Email, Gender from Customer", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;

                    }
                }
            }
        }
        void MunculData2()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select RoomNumber, RoomFloor, RoomPrice, Description from Room, RoomType", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView2.DataSource = dataTable;
                    }

                }
            }
        }
        void MunculData3()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select RoomNumber, RoomFloor, RoomPrice, Description from Room, RoomType", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView3.DataSource = dataTable;
                    }

                }
            }
        }
        void MunculData4()
        {
            






            //using (SqlConnection conn = Konn.GetConn())
            //{
            //    conn.Open();
            //    using (SqlCommand cmd = new SqlCommand("select Name, Qty, RequestPrice, TotalPrice  from ReservationRequestItem, Item", conn))
            //    {
            //        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            //        {
            //            DataTable dataTable = new DataTable();
            //            da.Fill(dataTable);
            //            dataGridView4.DataSource = dataTable;
            //        }

            //    }
            //}
        }

        public Reservation()
        {
            InitializeComponent();
            dateTimePickerCheckIn.ValueChanged += UpdateBiaya;
            dateTimePickerCheckOut.ValueChanged += UpdateBiaya;
            textBox4.TextChanged += UpdateBiaya;
            InitializeDataTable();
            InitializeDataGridView();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        public void tabelbawah()
        {
            DataTable tabel  = new DataTable();

            tabel.Columns.Add("Item",typeof(string));
            tabel.Columns.Add("Quantity",typeof(int));
            tabel.Columns.Add("Price",typeof (int));
            tabel.Columns.Add("Subtotal", typeof(int));
            //tabel.Columns.Add("Remove",typeof(Button));

            string item = comboBox2.Text;
            decimal quantity = numericUpDown1.Value;
            int subtotal = textBox4.Text.Length;
 

           
          

          
             



            dataGridView4.DataSource = tabel;
        }
        public void tblkanan()
        {
            DataTable tabel = new DataTable();


            tabel.Columns.Add("RoomNumber", typeof(int));
            tabel.Columns.Add("RoomFloor", typeof(int));
            tabel.Columns.Add("RoomPrice", typeof(int));
            tabel.Columns.Add("Description", typeof(string));





            dataGridView3.DataSource = tabel;
        }


        private void Reservation_Load(object sender, EventArgs e)
        {
            button4.Visible = false;
            textBox9.ReadOnly = true;
            awal();
            //tblkanan();

        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                label9.Visible = true;
                textBox1.Visible = true;
                panel1.Visible = false;
                dataGridView1.Visible = true;
                MunculData();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                label9.Visible = false;
                textBox1.Visible = false;
                panel1.Visible = true;
                dataGridView1.Visible = false;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            filter();

        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            LoadDataToComboBox();
        }

        void kanan()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Class (StudentID, StudentName, Kelas) VALUES (@StudentID, @StudentName, @Kelas)", conn))
                {
                    cmd.Parameters.AddWithValue("@StudentID", nilai6);
                    cmd.Parameters.AddWithValue("@StudentName", nilai4);
                    cmd.Parameters.AddWithValue("@Kelas", comboBox1.Text);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        //  Refresh();
                        MessageBox.Show("Data berhasil disimpan!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Terjadi kesalahan: " + ex.Message);

                    }
                }
            }
        }


        private void btnKanan_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView3.Columns.Count == 0)
                {
                    foreach (DataGridViewColumn dgvc in dataGridView2.Columns)
                    {
                        dataGridView3.Columns.Add(dgvc.Clone() as DataGridViewColumn);
                    }
                }

                DataGridViewRow row = new DataGridViewRow();

                row = (DataGridViewRow)dataGridView2.Rows[dataGridView2.CurrentRow.Index].Clone();
                int intColIndex = 0;
                foreach (DataGridViewCell cell in dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells)
                {
                    row.Cells[intColIndex].Value = cell.Value;
                    intColIndex++;
                }

                dataGridView3.Rows.Add(row);
                dataGridView3.AllowUserToAddRows = false;
                dataGridView3.Refresh();
                dataGridView2.Rows.RemoveAt(dataGridView2.CurrentRow.Index);
            }
            catch (Exception ex)
            {

            }
            UpdateBiaya(sender, e);




            //if (dataGridView2.ColumnCount == 0)
            //{
            //    foreach (DataGridViewColumn dgvc in dataGridView2.Columns)
            //    {
            //        dataGridView3.Columns.Add(dgvc.Clone() as DataGridViewColumn);
            //    }
            //}
            //DataGridViewRow row = dataGridView2.Rows[dataGridView2.CurrentRow.Index];
            //dataGridView3.Rows.Add(row);

        }



        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (e.RowIndex >= 0)
            //{
            //    DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
            //    nilai5 = row.Cells[1].Value.ToString();
            //    MessageBox.Show(nilai5);



            //if (dataGridView2.ColumnCount == 0)
            //{
            //    foreach (DataGridViewColumn dgvc in dataGridView2.Columns)
            //    {
            //        dataGridView3.Columns.Add(dgvc.Clone() as DataGridViewColumn);
            //    }
            //}
        }


        private void UpdateTextBox()
        {
            string selectedName = comboBox2.SelectedItem?.ToString();
            if (selectedName != null)
            {
                using (SqlConnection conn = Konn.GetConn())
                {
                    conn.Open();
                    string query = "SELECT RequestPrice FROM Item WHERE Name = @Name";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", selectedName);

                        object result = cmd.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            if (decimal.TryParse(result.ToString(), out decimal requestPrice))
                            {
                                textBox3.Text = requestPrice.ToString(); // Menampilkan harga satuan di textBox3

                                decimal multiplier = numericUpDown1.Value;
                                decimal total = requestPrice * multiplier;
                                textBox4.Text = total.ToString();
                            }
                            else
                            {
                                textBox3.Text = "Invalid Price";
                                textBox4.Text = "";
                            }
                        }
                        else
                        {
                            textBox3.Text = "Price not found";
                            textBox4.Text = "";
                        }
                    }
                }
            }
        }



        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTextBox();
            //using (SqlConnection conn = Konn.GetConn())
            //{


            //conn.Open();
            //{

            //    string query = "SELECT RequestPrice FROM Item where Name = @Name";
            //    //SqlCommand command = new SqlCommand("SELECT RequestPrice FROM Item where Name = @Name", conn);
            //    using (SqlCommand cmd = new SqlCommand(query, conn))
            //    {
            //        cmd.Parameters.AddWithValue("@Name", comboBox2.Text);
            //        SqlDataReader reader = cmd.ExecuteReader();


            //        while (reader.Read())
            //        {
            //            //int hasil = 0;  

            //            textBox3.Text = (reader["RequestPrice"].ToString());
            //            //textBox4.Text = (reader["RequestPrice"]());
            //            //hasil = (reader["RequestPrice"].)
            //        }

            //        reader.Close();
            //    }
            //}
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            UpdateTextBox();

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void InitializeDataTable()
        {
            table.Columns.Add("Item", typeof(string));
            table.Columns.Add("Quantity", typeof(int));
            table.Columns.Add("Price", typeof(int));
            table.Columns.Add("Subtotal", typeof(int));
        }

        private void InitializeDataGridView()
        {
            dataGridView4.DataSource = table;

            

            DataGridViewButtonColumn removeButtonColumn = new DataGridViewButtonColumn();
            removeButtonColumn.Name = "RemoveButton";
            removeButtonColumn.HeaderText = "Remove";
            removeButtonColumn.Text = "Remove";
            removeButtonColumn.UseColumnTextForButtonValue = true;
            dataGridView4.Columns.Add(removeButtonColumn);

            dataGridView4.CellContentClick += dataGridView1_CellContentClick;
        }

        private void button2_Click(object sender, EventArgs e)
        {


            string item = comboBox2.Text;
            int quantity = (int)numericUpDown1.Value;
            int price = int.Parse(textBox3.Text); 
            int subtotal = quantity * price;

            table.Rows.Add(item, quantity, price, subtotal);
            dataGridView4.DataSource = table;

            UpdateBiaya(sender,e);

            ////if (string.IsNullOrEmpty(comboBox2.Text) || string.IsNullOrEmpty(numericUpDown1.Text))
            ////{
            ////    MessageBox.Show("Pastikan Item Atau Quantity Tidak Kosong");
            ////}
            ////else
            ////{
            ////    try
            ////    {
            ////        using (SqlConnection conn = Konn.GetConn())
            ////        {
            ////            conn.Open();


            ////            string queryReservation = "INSERT INTO ReservationRequestItem ( Qty) VALUES ( @Qty)";
            ////            using (SqlCommand cmdReservation = new SqlCommand(queryReservation, conn))
            ////            {

            ////                cmdReservation.Parameters.AddWithValue("@Qty", Convert.ToInt32(numericUpDown1.Value));

            ////                cmdReservation.ExecuteNonQuery();
            ////            }


            ////            string queryItem = "INSERT INTO Item (Name) VALUES (@Name)";
            ////            using (SqlCommand cmdItem = new SqlCommand(queryItem, conn))
            ////            {
            ////                cmdItem.Parameters.AddWithValue("@Name", comboBox2.Text);


            ////                cmdItem.ExecuteNonQuery();
            ////            }

            ////            MessageBox.Show("ITEM BERHASIL DITAMBAHKAN");
            ////        }
            ////    }
            ////    catch (SqlException ex)
            ////    {
            ////        MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
            ////    }
            ////    catch (Exception ex)
            ////    {
            ////        MessageBox.Show("Terjadi kesalahan: " + ex.Message);
            ////    }
            //}
        }

        private void lblPrice_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {




        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnKiri_Click(object sender, EventArgs e)
        {
            if (dataGridView3.RowCount > 0)
            {
                DataGridViewRow row = new DataGridViewRow();

                row = (DataGridViewRow)dataGridView3.Rows[dataGridView3.CurrentRow.Index].Clone();
                int intColIndex = 0;
                foreach (DataGridViewCell cell in dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells)
                {
                    row.Cells[intColIndex].Value = cell.Value;
                    intColIndex++;
                }

                dataGridView2.Rows.Add(row);
                dataGridView2.AllowUserToAddRows = false;
                dataGridView2.Refresh();

                dataGridView3.Rows.RemoveAt(dataGridView3.CurrentRow.Index);

                UpdateBiaya(sender, e);

            }
        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView4.Columns[e.ColumnIndex] is DataGridViewButtonColumn && dataGridView4.Columns[e.ColumnIndex].Name == "RemoveButton")
            {
                if (e.RowIndex < table.Rows.Count)
                {
                    table.Rows.RemoveAt(e.RowIndex);
                    UpdateBiaya(sender, e);
                }
                else
                {
                    MessageBox.Show("Invalid row index.");
                }
            }
            
        }

        private void UpdateBiaya(object sender, EventArgs e)
        {
            DateTime checkInDate = dateTimePickerCheckIn.Value;
            DateTime checkOutDate = dateTimePickerCheckOut.Value;

            TimeSpan selisih = checkOutDate.Subtract(checkInDate);

            int selisihHari = (int)Math.Ceiling(selisih.TotalDays);
            textBox2.Text = selisihHari.ToString();

            int biayaDefaultPerHari = 1000000;
            int biayaKamar = 0;

            int sumKamar = 0;
            for (int i = 0; i < dataGridView3.Rows.Count; i++)
            {
                int valueFromCell;
                if (int.TryParse(dataGridView3.Rows[i].Cells[3].Value?.ToString(), out valueFromCell))
                {
                    sumKamar += valueFromCell;
                }
                else
                {
                   
                }
            }
            biayaKamar = sumKamar > 0 ? sumKamar : biayaDefaultPerHari;

            biayaKamar *= selisihHari;

            CultureInfo culture = new CultureInfo("id-ID");
            string biayaRp = biayaKamar.ToString("C0", culture);
            biayaRp = biayaRp.Replace("$", "Rp");

            int biayaItem = 0;

            if (dataGridView4.RowCount != 0)
            {
                int sumItem = 0;
                for (int i = 0; i < dataGridView4.Rows.Count; i++)
                {
                    int valueFromCell;
                    if (int.TryParse(dataGridView4.Rows[i].Cells[4].Value?.ToString(), out valueFromCell))
                    {
                        sumItem += valueFromCell;
                    }
                    
                }
                biayaItem = sumItem;
            }

            int totalPrice = biayaKamar + biayaItem;

            lblPrice.Text = "Total Price: " + totalPrice.ToString();
        }

        public string randomCode()
        {
            string hasil;
            string nama = "yoga";
            Random messi = new Random();

            int alok = messi.Next(1, 1000);

            hasil = (nama.Substring(0, 3) + (alok % 1000).ToString("D3"));
            Console.Write(hasil);

 

            int alok1 = messi.Next(1, 15);
          

           
            return hasil ;

        }

        

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            UpdateBiaya(sender, e);

            //// Ambil nilai dari DateTimePicker
            //DateTime checkin = dateTimePickerCheckIn.Value;
            //DateTime checkout = dateTimePickerCheckOut.Value;

            //// Hitung selisih hari antara kedua tanggal
            //TimeSpan selisih = checkout - checkin;
            //int jumlahHari = selisih.Days;

            //// Cek apakah selisih hari adalah 1
            //if (jumlahHari == 1)
            //{
            //    // Set label dengan harga
            //    lblPrice.Text = "Total Price: Rp. 1000000";
            //}
            //if (jumlahHari == 2)
            //{
            //    // Set label dengan harga
            //    lblPrice.Text = "Total Price : Rp. 2000000";
            //}
            //if (jumlahHari < 1)
            //{
            //    // Tampilkan peringatan
            //    MessageBox.Show("Checkin dan checkout harus berjarak minimal 1 hari");
            //}
            
           
        }
    



        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            UpdateBiaya(sender, e);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            dateTimePickerCheckOut.Value = dateTimePickerCheckIn.Value.AddDays(Int64.Parse(textBox2.Text));
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                try
                {
                    conn.Open();
                    string searchTerm = textBox1.Text.Trim();

                    string query = "SELECT Name, Email, Gender FROM Customer WHERE Name LIKE @Name";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", "%" + searchTerm + "%");

                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataTable dataTable = new DataTable();
                            da.Fill(dataTable);
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
                catch (Exception ex)
                {
                   
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(textBox6.Text) || string.IsNullOrEmpty(textBox7.Text) || string.IsNullOrEmpty(textBox8.Text) || string.IsNullOrEmpty(comboBox3.Text))
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();


                        string query = "INSERT INTO Customer (Name, NIK, Email, Gender, PhoneNumber) " +
                            "VALUES (@Name, @NIK, @Email, @Gender , @PhoneNumber)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox8.Text);
                            cmd.Parameters.AddWithValue("@NIK", textBox6.Text);
                            cmd.Parameters.AddWithValue("@Email", textBox5.Text);
                            cmd.Parameters.AddWithValue("@Gender", comboBox3.Text);
                            cmd.Parameters.AddWithValue("@PhoneNumber",textBox7.Text);


                            cmd.ExecuteNonQuery();
                            Refresh();
                        }

                        query = "select ID from Customer where Name = @Name";
                       

                        
                        using (SqlCommand cmd = new SqlCommand(@query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox8.Text);
                          



                            cmd.ExecuteNonQuery();
                            rd = cmd.ExecuteReader();
                            if (rd.Read())
                            {
                                
                                 CustomerID = rd.GetInt32(0).ToString();
                                //MessageBox.Show(CustomerID);
                                //string CustomerName = rd.GetString(1);
                                rd.Close();
                                Refresh();
                            }
                          

                        }

                        query = "INSERT INTO Reservation (Datetime, EmployeeID, CustomerID, BookingCOde) " +
                         "VALUES (@Datetime, @EmployeeID, @CustomerID, @BookingCOde)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                            
                        {

                            textBox9.Text = randomCode();
                            //string mainform;
                            MainFormm main = (MainFormm)Application.OpenForms["MainFormm"];

                            string UserID = main.userID;


                            //MessageBox.Show(UserID);
                            

                            cmd.Parameters.AddWithValue("@Datetime", DateTime.Now);
                            cmd.Parameters.AddWithValue("@EmployeeID", int.Parse(UserID) );
                            cmd.Parameters.AddWithValue("@CustomerID", int.Parse(CustomerID));
                            cmd.Parameters.AddWithValue("@BookingCOde", textBox9.Text);
                                                    


                            cmd.ExecuteReader();
                            Refresh();
                        }


                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show(randomCode());
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            int roomPrice = 0;
            UpdateBiaya(sender, e);
            if (!string.IsNullOrEmpty(textBox4.Text))
            {

/*                if (int.TryParse(textBox4.Text, out int numericValue))
                {
                    if (numericValue < 0)
                    {
                        MessageBox.Show("Gagal");
                    }
                    else
                    {
                        int totalprice = numericValue + roomPrice;
                        lblPrice.Text = "Total Price : " + totalprice.ToString();
                    }

                }
*/            }
    }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                btnKanan.Text = dataGridView3.CurrentRow.Index.ToString();
                string btnkanan = btnKanan.Text;
                MessageBox.Show(btnkanan);
            }


            //if (e.RowIndex >= 0)
            //{
            //    DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
            //    nilai4 = row.Cells[0].Value.ToString();
            //    MessageBox.Show(nilai4);

            // MessageBox.Show( nilai4 );



        }
    }
    }





