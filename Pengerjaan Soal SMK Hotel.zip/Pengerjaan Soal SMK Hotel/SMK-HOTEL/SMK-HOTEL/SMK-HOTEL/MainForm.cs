﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SMK_HOTEL
{
    public partial class MainFormm : Form
    {
        public MainFormm()
        {
            InitializeComponent(); Timer timer = new Timer();
            timer.Interval = 1000; // Set interval ke 1 detik
            timer.Tick += Timer_Tick;
            timer.Start();

          
        
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Mendapatkan waktu  dari sistem
            DateTime currentTime = DateTime.Now;

             
            LabelJam.Text = currentTime.ToLongTimeString(); // Tampilkan waktu
            LabelTanggal.Text = currentTime.ToLongDateString(); // Tampilkan tanggal
        }

        public string userID, Username;

private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            CustomerCheckin cscheckin = new CustomerCheckin();
          
            cscheckin.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStripLabel5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormLogin frmlog = new FormLogin();
            this.Close();
            frmlog.Show();
        }

        private void toolStripLabel4_Click(object sender, EventArgs e)
        {
            FormLogin frmlog = new FormLogin();
            this.Close();
            frmlog.Show();
        }

        private void toolStripLabel6_Click(object sender, EventArgs e)
        {
            MainFormFrontOffice mainfrmfrontoffice = new MainFormFrontOffice();
            mainfrmfrontoffice.Show();
            
        }

        private void checkInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerCheckin customerCheckin = new CustomerCheckin();
             
            customerCheckin.Show();
        }

        private void toolStripLabel2_Click(object sender, EventArgs e)
        {
            Reservation reservation = new Reservation();
            
            reservation.Show();
        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
            CheckOut checkout = new CheckOut(); 
            checkout.Show();
        }

        private void reservationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Reservation reservation = new Reservation();
            reservation.Show();
        }

        private void requestAditionalItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RequestAdditionalItems requestAdditionalItems = new RequestAdditionalItems();
            requestAdditionalItems.Show();
        }

        private void checkOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CheckOut checkOut = new CheckOut();
            checkOut.Show();
        }

        private void checkInToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ReportForm reportForm = new ReportForm();
            reportForm.Show();
        }

        private void guestsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void LabelTanggal_Click(object sender, EventArgs e)
        {

        }
    }
}
