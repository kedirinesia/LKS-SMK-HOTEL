﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.IO;

namespace SMK_HOTEL
{
    public partial class MasterFoodandDrink : Form
    {
        Connection Konn = new Connection();
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;
        private string selectedImagePath = "";


        public MasterFoodandDrink()
        {
            InitializeComponent();
        }
        void awal()
        {
            munculdata();
        }

        void munculdata()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select * from FoodsAndDrinks", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();


            openFileDialog.Filter = "File Gambar|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Semua File|*.*";
            openFileDialog.Title = "Pilih Gambar";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog.FileName);


            }
            Image selectedImage = Image.FromFile(openFileDialog.FileName);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;


            Bitmap resizedImage = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            using (Graphics g = Graphics.FromImage(resizedImage)) ;
        }

        private void MasterFoodandDrink_Load(object sender, EventArgs e)
        {
            awal();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(comboBox1.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();


                        Image image = pictureBox1.Image;
                        image.Save("temp.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
                        byte[] blob = System.IO.File.ReadAllBytes("temp.jpg");


                        string query = "INSERT INTO FoodsAndDrinks (Name, Type, Price, Photo) " +
                            "VALUES (@Name, @Type, @Price, @Photo)";
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                            cmd.Parameters.AddWithValue("@Type", comboBox1.Text);
                            cmd.Parameters.AddWithValue("@Price", textBox3.Text);
                            cmd.Parameters.AddWithValue("@Photo", blob);

                            cmd.ExecuteNonQuery();
                            Refresh();
                        }


                        System.IO.File.Delete("temp.jpg");

                        MessageBox.Show("DATA BERHASIL DIINPUT");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();





                        string query = "DELETE FROM FoodsAndDrinks WHERE Name = @Name";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Name", textBox1.Text);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("DATA BERHASIL DIHAPUS");
                                awal();
                            }
                            else
                            {
                                MessageBox.Show("Tidak ada data yang dihapus.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void Mesi()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "File Gambar|*.jpg;*.jpeg;*.png;*.gif;*.bmp|Semua File|*.*";
            openFileDialog.Title = "Pilih Gambar";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                selectedImagePath = openFileDialog.FileName;
                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                pictureBox1.Image = Image.FromFile(selectedImagePath);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string nilai = row.Cells[1].Value.ToString();
                string nilai1 = row.Cells[0].Value.ToString();
                string nilai2 = row.Cells[2].Value.ToString();
                string nilai3 = row.Cells[3].Value.ToString();
                //Image image = row.Cells[4].Value.ToString();

                textBox1.Text = nilai;
                comboBox1.Text = nilai2;
                textBox3.Text = nilai3;
                //pictureBox1.Image = image;






                //if (!string.IsNullOrEmpty(selectedImagePath))
                //{
                //    pictureBox1.Image = Image.FromFile(selectedImagePath);
                //}
                //else
                //{

                //    Mesi();
                //}
            }
        }



        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(comboBox1.Text) || string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("Tolong Isi Semua Form");
            }
            else
            {
                try
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();

                        using (MemoryStream ms = new MemoryStream())
                        {
                            pictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            byte[] blob = ms.ToArray();

                            string query = "UPDATE FoodsAndDrinks SET Name = @Name, Type = @Type, Price = @Price, Photo = @Photo WHERE YourConditionHere";
                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                                cmd.Parameters.AddWithValue("@Type", comboBox1.Text);
                                cmd.Parameters.AddWithValue("@Price", textBox3.Text);
                                cmd.Parameters.AddWithValue("@Photo", blob);

                                cmd.ExecuteNonQuery();
                                Refresh();
                            }
                        }
                        MessageBox.Show("DATA BERHASIL DIUPDATE");
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                }
                finally
                {
                    if (System.IO.File.Exists("temp.jpg"))
                    {
                        System.IO.File.Delete("temp.jpg");
                    }
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Data Berhasil Disimpan");
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox3.Clear();
             
             
        }
    }
}

 