﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Net.Mime.MediaTypeNames;

namespace SMK_HOTEL
{
    public partial class MasterRoom : Form
    {
        Connection Konn = new Connection();
        private SqlCommand cmd;
        private SqlDataAdapter da;
        private SqlDataReader rd;
        private DataSet ds;
        public DataTable tabel = new DataTable();
        bool Update = false;




        public void tabelRoomType()
        {

        }

        public void LoadDataToComboBox()
        {

            comboBox1.Items.Clear();

            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                {
                    SqlCommand command = new SqlCommand("SELECT  ID, Name FROM RoomType ", conn);


                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        DataRow row = tabel.NewRow();
                        row["RoomTypeID"] = reader["ID"];
                        row["Name"] = (reader["Name"].ToString());
                        tabel.Rows.Add(row);
                        comboBox1.Items.Add(reader["Name"].ToString());
                    }

                    reader.Close();
                }
            }
        }
        void awal()
        {
            munculdata();
            

            
            
            
            LoadDataToComboBox();

        }

        void munculdata()
        {
            using (SqlConnection conn = Konn.GetConn())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("select RoomNumber, RoomType.Name as RoomType, RoomFloor, Description from Room, RoomType where Room.RoomTypeID = RoomType.ID", conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dataTable = new DataTable();
                        da.Fill(dataTable);
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }

        }
        public MasterRoom()
        {
            InitializeComponent();
        }


        private void MasterRoom_Load(object sender, EventArgs e)
        {
            tabel.Columns.Add("RoomTypeID", typeof(int));
            tabel.Columns.Add("Name", typeof(string));
            //tabel.Rows.Add(new object[] { 1, "Smith", "John" });
            bisadiinput(false);
            awal();

           
             

        }



        public void bisadiinput(bool status)
        {
            button2.Enabled = !status;
            button3.Enabled = !status;
            button4.Enabled = !status;
            button5.Enabled = status;
            button6.Enabled = status;
            textBox1.Enabled = status;
            textBox2.Enabled = status;
            textBox3.Enabled = status;
            comboBox1.Enabled = status;
            dataGridView1.Enabled = !status;


        }

        private void button2_Click(object sender, EventArgs e)
        {

            bisadiinput(true);
            textBox1.Focus();
            MessageBox.Show("Berhasil Masuk Ke Menu Input");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            bisadiinput(false);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();



            MessageBox.Show("Berhasil Melakukan Cancel");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            bisadiinput(false);

            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) ||
                string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(comboBox1.Text))

            {
                MessageBox.Show("PASTIKAN SEMUA FORM DIISI");
            }

            else
            {
                if (Update == true)
                {
                    using (SqlConnection conn = Konn.GetConn())
                    {
                        conn.Open();
                        string query = "INSERT INTO Room (RoomNumber, RoomFloor, RoomTypeID, Description ) " +
                                       "VALUES (@RoomNumber, @RoomFloor, @RoomTypeID, @Description)";
                    }
                }
                else
                {


                    try
                    {
                        using (SqlConnection conn = Konn.GetConn())
                        {
                            conn.Open();
                            string query = "INSERT INTO Room (RoomNumber, RoomFloor, RoomTypeID, Description ) " +
                                           "VALUES (@RoomNumber, @RoomFloor, @RoomTypeID, @Description)";
                            using (SqlCommand cmd = new SqlCommand(query, conn))
                            {

                                cmd.Parameters.AddWithValue("@RoomNumber", textBox1.Text);
                                cmd.Parameters.AddWithValue("@RoomFloor", textBox2.Text);
                                cmd.Parameters.AddWithValue("@RoomTypeID", tabel.Rows[comboBox1.SelectedIndex][0].ToString());
                                cmd.Parameters.AddWithValue("@Description", textBox3.Text);

                                cmd.ExecuteNonQuery();
                            }


                            MessageBox.Show("DATA BERHASIL DIINPUT");
                        }
                    }
                    catch (SqlException ex)
                    {

                        MessageBox.Show("Terjadi kesalahan SQL: " + ex.Message);
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Terjadi kesalahan: " + ex.Message);
                    }
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string textbox = "A";


            textbox = tabel.Rows[comboBox1.SelectedIndex][0].ToString();
            //MessageBox.Show(textbox);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Update = true;
            

            bisadiinput(true);
            textBox1.Focus();

            




            //if (dataGridView1.SelectedRows.Count > 0)
            //{ 
            //    int selectedIndex = dataGridView1.SelectedRows[0].Index;
            //    int selectedIndex1 = dataGridView1.SelectedRows[1].Index;
            //    int selectedIndex2 = dataGridView1.SelectedRows[2].Index;
            //    int selectedIndex3 = dataGridView1.SelectedRows[3].Index;

            //    textBox1.Text = dataGridView1.Rows[selectedIndex].Cells[0].Value.ToString();
            //    textBox2.Text = dataGridView1.Rows[selectedIndex1].Cells[0].Value.ToString();
            //    textBox3.Text = dataGridView1.Rows[selectedIndex2].Cells[0].Value.ToString();
               
            // }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            textBox1.Text = row.Cells["RoomNumber"].Value.ToString();
            textBox2.Text = row.Cells["Description"].Value.ToString();
            textBox3.Text = row.Cells["RoomFloor"].Value.ToString();
            
            comboBox1.Text = row.Cells["RoomType"].Value.ToString();
        }
    }
}

